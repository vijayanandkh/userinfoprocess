package com.example.flows.main

import android.os.Bundle
import com.example.countriesqz.ui.main.MainFragment
import com.example.flows.R
import dagger.android.support.DaggerAppCompatActivity

class FirstActivity : DaggerAppCompatActivity()  {

        override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.first_activity)
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                    .replace(R.id.container, MainFragment.newInstance())
                    .commitNow()
        }
    }

}