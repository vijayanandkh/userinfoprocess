package com.example.flows.main

import com.example.flows.error.ResultWrapper
import com.example.flows.extensions.safeApiCall
import com.example.flows.main.data.User
import com.example.flows.main.local.UserDao
import com.example.flows.main.network.MainActivityApi
import com.example.flows.main.network.RemoteDataSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject

class MainActivityRepository @Inject constructor(private val userDao: UserDao, private val countryRds: RemoteDataSource, private val api: MainActivityApi) {

//    @ExperimentalCoroutinesApi
//    fun getSearchedCountry(search: String): Flow<List<Country>> {
//        return countryDao.getSearchedCountry(search) //Get searched dogs from Room Database
//            //Combine the result with another flow
////            .combine(topCountriesFlow) { countries, search ->
////                countries.applyToCountry(topCountries)
////            }
//            .flowOn(Dispatchers.Default)
//            //Return the latest values
//            .conflate()
//    }

    @ExperimentalCoroutinesApi
    fun getSearchedUser(search: String): Flow<List<User>> {
        return userDao.getSearchedUser(search) //Get searched dogs from Room Database
            //Combine the result with another flow
//            .combine(topCountriesFlow) { countries, search ->
//                countries.applyToCountry(topCountries)
//            }
            .flowOn(Dispatchers.Default)
            //Return the latest values
            .conflate()
    }



    @ExperimentalCoroutinesApi
    fun getSearchedUserId(search: String): Flow<List<User>> {
        return userDao.getSearchedUserId(search) //Get searched dogs from Room Database
            //Combine the result with another flow
//            .combine(topCountriesFlow) { countries, search ->
//                countries.applyToCountry(topCountries)
//            }
            .flowOn(Dispatchers.Default)
            //Return the latest values
            .conflate()
    }


    suspend fun tryFetchAndUpdate(): ResultWrapper {

//        val api = safeApiCall(Dispatchers.IO) { api.getAllCountries("name","capital", "currencies", "region") }
        val api = safeApiCall(Dispatchers.IO) { api.getAllUsers() }
        when (api) {
            is ResultWrapper.Success<*> -> {
                val userApiResponse = api.value as ArrayList<User>
                val users = userApiResponse.apply {
                    this.forEach {
                        if(null != it.userId) userDao.save(it)
                    }
                }
            }
        }
        return api
    }
//
//    private fun List<Country>.applyToCountry(favoritesSortOrder: List<String>): List<Country> {
//        return this.map {
//            val isTopCountry = favoritesSortOrder.contains(it.name!!.capitalize())
////            Country(it.name, it.capital, it.currencies, it.region)
//            Country(it.name, it.capital, it.region, it.flagImageUrl)
//        }
//    }
    private fun List<User>.applyToUser(favoritesSortOrder: List<String>): List<User> {
        return this.map {
            val isTopCountry = favoritesSortOrder.contains(it.userId!!.capitalize())
//            Country(it.name, it.capital, it.currencies, it.region)
            User(it.id, it.userId, it.title, it.body)
        }
    }


    suspend fun clearCacheData() {
        try {
            userDao.deleteCache()
        } catch (error: Throwable) {

        }
    }
}
