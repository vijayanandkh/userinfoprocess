package com.example.flows.main.local

import androidx.room.*
import com.example.flows.main.data.User
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(user: User)

    @Query("SELECT * FROM user")
    fun loadAllEpisodesFlow(): Flow<List<User>>

    @Query("SELECT count(*) FROM user")
    fun getNumberOfUsers(): Int

    @Query("DELETE FROM User")
    suspend fun deleteCache()

//    @Query("SELECT * FROM country WHERE name LIKE '%' || :search || '%'")
//    fun getSearchedCountry(search: String?): Flow<List<Country>>

    @Query("SELECT * FROM user WHERE userid LIKE '%' || :search || '%'")
    fun getSearchedUser(search: String?): Flow<List<User>>

    @Query("SELECT * FROM user WHERE id LIKE '%' || :search || '%'")
    fun getSearchedUserId(search: String?): Flow<List<User>>

}