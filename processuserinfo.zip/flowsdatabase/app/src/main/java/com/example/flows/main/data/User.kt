package com.example.flows.main.data

import androidx.annotation.NonNull
import androidx.room.Entity
import androidx.room.PrimaryKey

//     "userId": 1, id, title, body

@Entity
data class User (
    @PrimaryKey
    @NonNull
    val id: Int,
    val userId: String,
    val title: String,
    val body: String
)