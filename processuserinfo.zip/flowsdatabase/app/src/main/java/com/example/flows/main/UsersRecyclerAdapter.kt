package com.example.flows.main

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.flows.R
import com.example.flows.extensions.inflate
import com.example.flows.main.data.User
import kotlinx.android.extensions.LayoutContainer
import kotlinx.android.synthetic.main.item_country.view.*


class UsersRecyclerAdapter : ListAdapter<User, UsersRecyclerAdapter.UserDateViewHolder>(UserDataAdapterListDiff()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserDateViewHolder =
        UserDateViewHolder(parent.inflate(R.layout.item_country))

    override fun onBindViewHolder(holder: UserDateViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    private class UserDataAdapterListDiff : DiffUtil.ItemCallback<User>() {

        override fun areItemsTheSame(oldItem: User, newItem: User): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: User, newItem: User): Boolean {
            return oldItem.id == newItem.id        }
    }

    inner class UserDateViewHolder(override val containerView: View) :
        RecyclerView.ViewHolder(containerView), LayoutContainer {

        fun bind(user: User) {
            containerView.name.text = user.userId

            containerView.capital.text = user.id.toString()
//            containerView.currencyname.text = country.currencies?.get(0)?.code ?: country.currencies?.get(0)?.name
//            country.flagImageUrl?.let {
//                    it1 -> ImageLoader.loadImageWithCircularCrop(containerView.context, it1, containerView.image) }

            containerView.currencyname.text = user.body?: "---"
//            this.containerView.card_layout.setCardBackgroundColorundColor(containerView.context.getColor(R.color.colorPrimary))
        }
    }
}