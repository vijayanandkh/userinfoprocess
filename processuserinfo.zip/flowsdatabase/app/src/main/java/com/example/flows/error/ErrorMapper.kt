package com.example.flows.error


class ErrorMapper {

    internal companion object {

    }

//    @StringRes
//    fun mapOf(error: String): Int {
//        return when (error) {
//
//        }
//    }
}