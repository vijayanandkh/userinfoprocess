package com.example.flows.main.network

import com.example.flows.main.data.User
import retrofit2.http.GET

interface MainActivityApi {

    @GET("posts")
    suspend fun getAllUsers() : List<User>


}