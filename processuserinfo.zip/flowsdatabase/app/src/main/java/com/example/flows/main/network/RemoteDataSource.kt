package com.example.flows.main.network

import com.example.flows.main.data.User
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import javax.inject.Inject

class RemoteDataSource @Inject constructor(private val api: MainActivityApi) {

//
//    suspend fun fetchCountriesInfo(): List<Country> = withContext(Dispatchers.IO) {
////        val result = api.getAllCountries()
////        val result = api.getAllCountries("name","captial", "currencies", "region")
//        val result = api.getAllCountries("name;capital;region;flag")
//        extractCountries(result)
//    }!!



    suspend fun fetchUsersInfo(): List<User> = withContext(Dispatchers.IO) {
//        val result = api.getAllCountries()
//        val result = api.getAllCountries("name","captial", "currencies", "region")
        val result = api.getAllUsers()
        extractUsers(result)
    }!!


    private fun extractUsers(users: List<User>): List<User>? {
        val resUsers = users.sortedBy { it.id }
        return resUsers
    }

    fun getAnyUser() = flow {
        while (true) {
            val list = getUsers().map { it }.shuffled().subList(0, 50)
            emit(list)
            delay(2000)
        }
    }

//    private fun getCountries() = listOf<Country>()
    private fun getUsers() = listOf<User>()
}