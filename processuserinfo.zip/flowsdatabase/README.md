# flows_guide

An android application to build an app using Flows and Channels while using Room database as single Source of truth , while fetching data using Retrofit and saving it to database.


A guide for this android application on [Medium](https://medium.com/@shivamdhuria/implementing-search-filter-using-kotlin-channels-and-flows-in-your-android-application-df7c96e58b19)
